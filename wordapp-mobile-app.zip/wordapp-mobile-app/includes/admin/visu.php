<?php
$varColor = (array) get_option('WordApp_options');
$varMenu = (array) get_option('WordApp_menu');
$varStructure = (array) get_option('WordApp_structure');
$varSlideshow = (array) get_option('WordApp_slideshow');
$varGA = (array) get_option('WordApp_ga');
$fullVar = array_merge($varColor, $varMenu, $varStructure, $varSlideshow, $varGA);

?>
<h3>Hi</h3>

<script>



</script>
