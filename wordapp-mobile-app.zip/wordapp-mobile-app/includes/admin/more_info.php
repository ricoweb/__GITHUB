<div style="top:-37px;position: relative;"><img src="<?php echo plugins_url(APPNAME.'/images/newsletter.png')?>" style="width:90%;">

<h3><?php _e( 'More Links','wordapp-mobile-app');?></h3>
<ul>
	<li><a href="admin.php?page=WordAppCrowd"><font color="red">*** <?php _e( 'We need your help!','wordapp-mobile-app');?> *** </font></a></li>

<li><a href="admin.php?page=WordAppMoreDownloads"><?php _e( 'Get app for free!','wordapp-mobile-app');?></a></li>

</ul>
	<h3><?php _e( 'Help us grow','wordapp-mobile-app');?></h3>
	<p><?php _e( 'We promise to invest every cent in to improving the plugin.','wordapp-mobile-app');?></p>
										<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="7YT8F3PTRL6LG">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>

	
	<p><b><?php _e( 'Become a reseller','wordapp-mobile-app');?></b> <br> <?php _e( 'Build Unlimited Apps','wordapp-mobile-app');?> <a href="https://app-developers.biz/agencies/" target="_blank"><?php _e( 'More information','wordapp-mobile-app');?></a></p>
</div>