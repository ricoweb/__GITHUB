<?php
/* Declaring Indexes */

			if(!isset($varColor))  $varColor = array();
       		if(!isset($varMenu))  $varMenu = array();
        	if(!isset($varStructure))  $varStructure = array();
        	if(!isset($varSlideshow))  $varSlideshow = array();
			if(!isset($wamenu))  $wamenu = array();
			if(!isset($data))  $data = array();
			if(!isset($Color))  $Color ='';

			if(!isset($data['Title'])) $data['Title']='';
			if(!isset($data['Color'])) $data['Color']='';
			if(!isset($data['logo'])) $data['logo']='';
			if(!isset($data['style'])) $data['style']='';
			if(!isset($data['page_id'])) $data['page_id']='';
		
			if(!isset($varColor['Title'])) $varColor['Title']='';
			if(!isset($varColor['Color'])) $varColor['Color']='';
			if(!isset($varColor['logo'])) $varColor['logo']='';
			if(!isset($varColor['style'])) $varColor['style']='';
			if(!isset($varColor['page_id'])) $varColor['page_id']='';
			if(!isset($varMenu['side'])) $varMenu['side']='';
			if(!isset($varMenu['top'])) $varMenu['top']='';
			if(!isset($varMenu['menu'])) $varMenu['menu']='';
			if(!isset($varMenu['menuTop'])) $varMenu['menuTop']='';
			if(!isset($varMenu['bottom'])) $varMenu['bottom']='';
			if(!isset($varMenu['menuBottom'])) $varMenu['menuBottom']='';
			if(!isset($varMenu['menuTop'])) $varMenu['menuTop']='';
			if(!isset($varStructure['icon'])) $varStructure['icon']='';
			if(!isset($varStructure['splash'])) $varStructure['splash']='';
			if(!isset($varStructure['description'])) $varStructure['description']='';
			if(!isset($varStructure['keywords'])) $varStructure['keywords']='';
			if(!isset($varStructure['cat'])) $varStructure['cat']='';
			if(!isset($varSlideshow['one'])) $varSlideshow['one']='';
			if(!isset($varSlideshow['two'])) $varSlideshow['two']='';
			if(!isset($varSlideshow['three'])) $varSlideshow['three']='';
			if(!isset($varSlideshow['four'])) $varSlideshow['four']='';
			if(!isset($varSlideshow['five'])) $varSlideshow['five']='';
			if(!isset($varColor['Title'])) $varColor['Title']='';
			if(!isset($varStructure['description'])) $varStructure['description']='';
			if(!isset($varStructure['cat'])) $varStructure['cat']='';
			if(!isset($varStructure['icon'])) $varStructure['icon']='';
			if(!isset($varStructure['splash'])) $varStructure['splash']='';
			if(!isset($varStructure['certificate'])) $varStructure['certificate']='';
						
						
			if(!isset($varAdMob['admobActive'])) $varAdMob['admobActive'] ='';
			if(!isset($varAdMob['AndroidBanner'])) $varAdMob['AndroidBanner'] ='';
			if(!isset($varAdMob['AndroidInterstitial'])) $varAdMob['AndroidInterstitial'] ='';
			if(!isset($varAdMob['iOSBanner'])) $varAdMob['iOSBanner'] ='';
			if(!isset($varAdMob['iOSInterstitial'])) $varAdMob['iOSInterstitial'] ='';

			if(!isset($data['Title'])) $varColor['Title']='';
			if(!isset($data['Color'])) $data['Color']='';
			if(!isset($data['logo'])) $data['logo']='';
			if(!isset($data['style'])) $data['style']='';
			if(!isset($data['page_id'])) $data['page_id']='';
			if(!isset($varMenu['side'])) $varMenu['side']='';
			if(!isset($varMenu['top'])) $varMenu['top']='';
			if(!isset($varMenu['menu'])) $varMenu['menu']='';
			if(!isset($varMenu['menuTop'])) $varMenu['menuTop']='';
			if(!isset($varMenu['bottom'])) $varMenu['bottom']='';
			if(!isset($varMenu['menuBottom'])) $varMenu['menuBottom']='';
			if(!isset($varMenu['menuTop'])) $varMenu['menuTop']='';
			if(!isset($varCss['css'])) $varCss['css']='';
			if(!isset($_GET['WordApp_demo'])) $_GET['WordApp_demo'] = "";
			if(!isset($varColor['ColorText'])) $varColor['ColorText']='#ffffff';
			if(!isset($varColor['ColorTextHHH'])) $varColor['ColorTextHHH']='';
			if(!isset($varColor['ColorTextP'])) $varColor['ColorTextP']='';
			if(!isset($varColor['ColorTextFont'])) $varColor['ColorTextFont']='';
			if(!isset($varColor['ColorTextFontHHH'])) $varColor['ColorTextFontHHH']='';
			if(!isset($varColor['ColorTextFontP'])) $varColor['ColorTextFontP']='';
			if(!isset($varGA['apiDomain'])) $varGA['apiDomain']='';
			
			if(!isset($varColor['background'])) $varColor['background']='';
			if(!isset($varColor['logo'])) $varColor['logo']='';
			
			
			
			if(!isset($wamenu['top'])) $wamenu['top']='';
			if(!isset($wamenu['rsideicon'])) $wamenu['rsideicon']='';
			if(!isset($wamenu['lsideicon'])) $wamenu['lsideicon']='';
			if(!isset($wamenu['rside'])) $wamenu['rside']='';
			
			if(!isset($varMenu['rside'])) $varMenu['rside']='';
			if(!isset($varMenu['menuRight'])) $varMenu['menuRight']='';
			
			

