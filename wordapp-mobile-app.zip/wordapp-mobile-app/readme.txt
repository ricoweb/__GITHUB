=== WordApp Mobile App Plugin - Convert your WordPress Site to a Mobile App ===
Contributors: mobilerockstar, App-Developers.biz
Donate link: https://app-developers.biz/invite-for-free/
Tags: mobile, mobile app, mobile app plugin, Woocommerce, wordapp, mobile plugin, BuddyPress, convert to mobile app, mobile app converter, iphone, app, ipod, theme, apple, mac, wordpress, mobile, android, smartphone, apps,iOS,WordPress mobile, WordPress mobile app, mobile blog app, BuddyPress app,iOS app, app builder, build a mobile app, WooCommerce app, mobile application,build mobile apps, create blog app, native app plugin, website to mobile app, native mobile app, build an app, wordpress app, wordpress iphone, wordpress android,make an app
Requires at least: 2.7
Tested up to: 4.8
Stable tag: 2.0.3
License: GPLv2 or later
Text Domain: wordapp-mobile-app
Domain Path: /languages
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Convert your WordPress site to a native mobile app for android & iOS. Free Mobile app plugin.

== Description ==

[Mobile App plugin](http://app-developers.biz) - WordApp | Convert your blog or WordPress site in to a **Mobile App** for iPhone & Android Native app & **Mobile site** in one. Now **WooCommerce** & **BuddyPress** Compatible

[youtube https://www.youtube.com/watch?v=WV--72wm4NM]

Mobile App - WordApp is a WordPress **mobile plugin** that converts your blog/website in to a mobile app & mobile website. Built by a community of mobile app geeks we are really proud to offer the very first mobile app plugin for wordpress.

Simply install the our mobile app plugin and choose one of our amazing templates your site will be instantly converted in to a mobile app. The mobile app templates are full customizable or you can even use your own.

**Make your own mobile app!**



Great new native features for your mobile app. Convert your wordpress website into a mobile app.Mobile App Plugin iPhone & Android Make your WordPress website to a Mobile app & mobile website.Make a mobile app - Native iPhone & Android Mobile App FREE, Mobile App API WordPress plugin lets you turn your website into a full-featured mobile application in minutes using Mobile App Builder

Thanks to the power of the WordPress Customizer you can build your mobile app and see the changes live in our mobile app simulator.


**Create your own Native mobile app for iPhone & Android **


Becoming quickly #1 App Builder in the our mobile world.

Some of the mobile app builder features :
* Automatic content sync -- Your mobile app is sync’d with your website and all changes to your websites content will automatically sync with your app.
* Customize your app live - Change colors, style, template, fonts (google fonts), icons, and upload your own logo and images.
* A mobile app that will work on iOS and Android (Windows Phone soon).
* We will publish the app for you. If you don’t want to publish you app we will do it for you.
* **Mobile app advertising and monetisation** - Thanks to AdMob you can now earn money from your app.

**Amazing native mobile plugins**
We have pre-installed plugins that will add even more functionality to your mobile app.

* QR Code reader
* Push Notifications
* GEOlocation - Track location once, or repeatedly
* Mobile App Ratings - Get more ratings
* iBeacons - Send a Push notification to your mobile app as users go past a beacon.
* Your mobile app on iOS and Android (soon Windows)

Need More?

* FASTEST mobile app builder out there. Your mobile app will be delivered to your email as quick and 30 minutes.
* 30+ beautiful themes all for FREE.
* Publish your mobile app to Google Play Store & Apple App Store.
* Send push notifications when you want to update your users
* Mobile web app for mobile browsers
* Customise the menus & widgets for mobile only users
* Mobile only content.
* Monetize you mobile app with Adsense ads & AdMob.
* Edit the CSS to create your own mobile theme.
* Compatible with BuddyPress.
* iBeacon Compatible mobile apps.
* Must smaller and faster navigation
* Versioning

Make your Mobile app today for free! In only 2 minutes, you can build a mobile app that's available worldwide. Now, You can make an iPhone mobile app or Android mobile app, with no programming skills needed.


> **Easy as 1-2-3**
>
> **1. Install and Activate the WordApp Mobile App Plugin **
>
> Take our simple 3 step install and make your own mobile app.
>
> **2. Customize **
>
> From our mobile plugin you can choose the colors, fonts, logo and content to use in your app. You will have a live preview as you make the changes.
>
>
> **4. Click publish **
>
> Our team will create your mobile app for free and send it to your email. On average the android app will take 30 minutes to 2 hours to be built.
>
> **Your mobile app can be in the Google Play store only a within couple of hours**



Native mobile apps can be uploaded to **Google Play** and the **iPhone App Store** The mobile website is supported on iPhones, Android smartphones, Windows Phone 8, Firefox OS.

You can now integration with our **mobile plugin** of **BuddyPress** & **WooCommerce**

**Compatible browsers**: Safari, Google Chrome, Android - Native Browser, Internet Explorer 10 and Firefox.

**NEW!** You can now build mobile apps for ecommerce (using BuddyPress), Forum (using bbPress), Dating App, and much more. Thanks to the power behind wordpress you can install all the plugins on your mobile app too.

Some of the more features & other services we offer :
* Creation of Native mobile apps
* Integration with all plugins
* Geo Targeted mobile Push notifications
* Mobile Themes customisation
* Mobile site design
* Upload service

Premium Mobile app with push notifications
1. Your mobile site html app is free forever.
2. If you invite 8 people your android app is free to for one month.
3. Premium features and you will get iOS app, android app, html mobile site, push notifications and all the premium features.


**What our users say **

> By myleokart
>
> Excellent plugin with good support and free app builder.


> By spelunk68
>
> Every once in a while you find one of those plugins where it is incredible the amount of work that someone has done creating a plugin, and it is available at such a minimal cost, then to top it off the author is very responsive with communications to any issues you may have and strives to help you find a solution.
> This is one of those rare type of plugins and plugin authors..
> Publish your wordpress site as an app that is available in the google and apple stores.
> The amount of work he put into this plugin and the results are impressive and just > what I was looking for. Wordapp allows me to take my site to the next level with a > whole new world of monetizing options now that it is available when someone searches for my sites content in their app store.
>
> If you have the need I would try this plugin, you can get an idea of ho your app will look and perform without ever spending a penny, then once you are comfortable you can take it to the app stores for such a minimal cost.


> By vinodalbal
> I am very much impressed with this plugin, never had any issues or problems using the plugin. What made me to give 5 stars is that super support from developers.
> Thank you Dave & team for the great plugin and support..!


**Admob Ads**
WordApp is Free and earn money with admit ads on your mobile app. We also display “powered by WordApp mobile plugin for wordpress” link. By upgrading to premium you will remove all ads and can even display your own mobile ads to monetize your mobile app.


**Thanks for all your feedback. Thanks to all your suggestions we have rebuilt the mobile app builder. You can now use any of the 50,000+ wordpress plugins**

**GET OUR MOBILE APP PLUGIN FOR FREE**

Invite 8 friends and we will create your android mobile app plugin for free!


Thanks to the amazing power of wordpress you can change many of your mobile apps features straight in the admin panel.


Keep customers happy and connected by providing a more personalized and relevant engagement experience.
Do-it-yourself solution is recommended for small businesses. You’ll create your own mobile app. We provide the tips and guidance. You take control.

New mobile app preview. Easily preview all our mobile app plugin features.

Make a mobile app for FREE thanks for all your support and kind remarks by email.

**Why your business or blog needs a mobile app**

There are now more than 500 million iPhone's in the world. Want the chance to reach out to every one of them? Build a mobile app today.

A Mobile app increases visibility.

Statistics show that the average American spends more than two hours a day on his or her mobile device.

A Mobile app creates a Direct Marketing Channel

a Mobile app serve many functions: they can provide general info, contact prices, reserve forms, search engines, user accounts, messengers, news feeds, events, special deals and even more. Thanks to push notifications you can get even closer and directly interact from your mobile app to your client.

Ad Revenue
Earn money with your mobile app by activating ads. Build your audience and earn money every time they use your mobile app.

Your app will build brand awareness

A mobile app for your business can greatly contribute to your brand awareness.

Customer engagement through the mobile app.

Make it easy for your readers or customers to contact you. Your mobile app plugin will help you build better customer relations.

Stand Out From the Competition thanks to your mobile app.

Having a mobile app for is still quite rare, this can give you a leap in advance against your competition.

All of this thanks to a mobile app built in a couple of seconds using our amazing mobile app plugin for WordPress

Make your **Mobile app** today for free! In only 20 minutes, you can build a mobile app that's available worldwide. Now, You can make an iPhone mobile app or Android mobile app, with no programming skills needed.

**Coming in the future. On our mobile app plugin**

* Post push notifications - Send a message as soon as you post a new post on your blog.
* Windows Phone your app will be available on Windows Mobile.
* More mobile plugins to add more functions to your app.
* More templates & themes to make better apps.
* Multi-Language the plugin in your language (see below)
* White label version - Don't want people to know about WordApp? White label our plugin.
* More methods to monetize your app
* More stats - Track your user base and easily view your return on investment.
* Got an idea please send your ideas to dave@app-developers.biz
* Thousands of fully customizable mobile app templates to select from.
*


Plugin To Turn WordPress Into A Mobile App aimed at developers & non-developers. You can build a mobile app with no coding skils.

With no programming needed, publish your app, promote your business, and gain more mobile customers with ease.


A mobile app to reach customers around the world on the App Store for iPhone, Android and soon iPad, Mac, Apple Watch, and Apple TV. You’ll also get access to marketing stuff, advanced app capabilities, and soon app analytics.

WordApp makes it easy for over a 20,000 customers around the world to discover and build a mobile app.

WordApp is jam-packed with great mobile features to boost sales, notify and engage users, schedule events, find locations, serve up multimedia content and more.

It's incredibly rapid to build a mobile app integrate the latest cutting-edge iOS & Android mobile technologies into your apps quickly, soon  watchOS, and tvOS. You’ll always be ready for what’s coming next as you create the most innovative mobile app ever.

**WordApp mobile Plugin in your Language!**
Currently a huge translation project is underway, translating the WordApp mobile pluginin as much as 24 languages. So far, the translations for the app builder French, Spanish, German and Dutch are on the way, but we still need help on a lot of other languages, so if you're good at translating, please join us at: http://app-developers.biz


As an open source company our community means everything to us. We love to here what you think about our mobile app builder. Here’s what some of our WordApp users think.

** Support & Help **

If you have any questions about your app mobile:

You can contact me on (Head mobile app developer) :

Support : http://app-developers.biz/forums/ (Mobile app plugin related questions only)

Phone USA : (650) 250-4245

Youtube tutorials : https://www.youtube.com/c/DaveASargent

Website : [Mobile App plugin | App-developers](http://app-developers.biz)

Support Website : [WordApp Mobile app plugin - Support & Help desk](http://support.app-developers.biz)

**Get social with us **

Twitter : @appdevelopersfr

Facebook : https://www.facebook.com/AppDevelopersBiz

SnapChat : @AppDevelopers

Instagram : @appdevelopersbiz


**Who are App-Developers.biz**
Built by Dave a mobile app developer. Since 2001 we have been building software, we came across a problem with mobile. Building a mobile app was expensive and bringing mobile technology to SMBs and bloggers was generally too expensive. This is where building WordApp came from.
WordApp is now a mobile first company. Our life is now Mobile, mobile, mobile.
Now app-developers - create mobile marketing solutions for your mobile clients.

WordApp mobile plugin Premium offers a variety of enhanced mobile themes for blogs, businesses, buddypress and WooCommerce retailers; top-notch one-on-one support from our mobile expert team.

Don't miss out on this opportunity to reach out to your mobile visitors and increase the amount of returning mobile users. Thanks to our amazing mobile app plugin you can build a mobile app within a couple of minutes and for FREE.

If you love WordPress this DIY mobile app maker is great for Small Businesses & Bloggers alike.

**Mobile app plugin**

== Installation ==

2.6 and Older You will have to upgrade. Unfortunately we don’t support 2.6 and lower.

VIA THE WORDPRESS PLUGINS PANEL
2.7+
1. Simply search the add plugins feature for “WordApp” on wordpress admin panel.
2. Click to install
3. Activate the plugin & you are ready to go!

MANUAL INSTALL
1. Upload `WordApp` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

You will also be requested to install 2 other plugins. Simply click begin install in the wordapp control panel.

== Frequently asked questions ==

= Are the mobile apps native? =
Yes, they are native mobile apps & are submitted to the app store and google play.

= Is it really Free? =
Yes, you can use & create your mobile app for free. You only need to upgrade to publish your app :).

= Are there any premium options? =
Yes, to get the iOS & android mobile app and if you want to send push notifications you will be charged a monthly fee from $0.99.

= Can I just upload to android/iphone =
Yes, you can choose either or both.

= What about windows phone? =
We are currently working on a windows phone addon.

= Can I use a WooCommerce site? =
Yes, it does now. We have created a free woo commerce theme.

= Do you take any of my personal information? =
Yes, for us to be able to send you, your app we need your email address. We also need the blog url to populate your app.

= Do you own the copyright to the apps' content? =
You of course you own the copyright to your content.

= What processes do you have to update the app? =
The content stays on your site the app is updated via json.

= What process do you have to delete the app? =
The app is published to your account on google play & the app store so you can delete it at any time. If you want to upload to our account "just drop us an email".

= What happens to the APKs etc if you go broke? =
You receive a copy of the APK via email. The APK will continue to work if we go broke.

= What is your Privacy Policy? =
http://app-developers.biz/blog/privacy

= What are your complete Terms and Conditions? =
http://app-developers.biz/blog/terms


= How long does it take to validate my app? =
Once you publish your app, it will go through several stages.
1. We will build the app for you around (48 hours)
2. You are we will publish you app to Apple & Google.
3. You app will go through a validation process.
 - Apple do not state a delay for validation but we normally see apps validated with 10 working days (but this is up to Apple).
 - Google is much faster and you should generally see your app in all stores with 24 hours.


= Will this plugin work on MU =
Yes, we have tested on Mu if you do encounter any problems please drop me a mail dave@app-developers.biz

= Can I install on local machine =

No, due to the way the app framework works (fetching the json) you must have a domain name/public static IP.

== Screenshots ==

1. Our dashboard - get latest news about mobile app marketing.
2. Customise your mobile app color & structure.
3. Creating a slideshow.
4. Mobile app template Automobile
5. Mobile app template SMB
6. Mobile app template Night Club
7. Box set :)
8. Push notifications
== Changelog ==

= Version 0.1 =
* Initial release
= Version 0.1 =
* Initial release
= Version 0.2 =
* Fix a couple of bugs
= Version 0.3 =
* Fixed image problems
* Fixed email bug
* Fixed init error message
= Version 1.0 =
Huge changes have been made to the structure of the app builder.
* Fixed any bugs
* Added new builder
* Improve the compatibility with other plugins BuddyPress, forms etc
* Mobile site builder added
= Version 1.0.1 =
* Fixing bug showing the wordapp instead of client server
= Version 1.0.2 =
* Image upload fixed
= Version 1.0.3 =
* Better widgets now you can define the widgets used in the widgets section of wordpress
= Version 1.0.4 =
* 1.0.3 didn’t upload correctly
* Better widgets now you can define the widgets used in the widgets section of wordpress
= Version 1.1 =
* Added 1 extra month for free
* Extra plugins added
= Version 1.1.1 =
* CSS Editor
* Faster loading theme
= Version 1.2.1 =
* Improved image uploader
* Unlock clicking
= Version 1.3 =
* Install of latest apps SDK
= Version 1.4 =
* Upgrades to work with 4.2.3
= Version 1.5 =
* Better theme integration
= Version 1.7 =
* Critical updates
= Version 1.8 =
* Improvements on user interface.
= Version 1.9 =
* Added some amazing marketing gear.
* Improved woocommerce integration
= Version 1.9.1 =
* Removed error message on dashboard
* Ads integration
= Version 1.9.3 =
* Integration of 4.3
* We are adding a better plugin system
= Version 1.10 =
* Amazing new themes
* More plugins
= Version 1.11 =
* Improving android & iOS app
* More push notification features
* Better white labelling
* Reduce in PRO price
* Use my default theme
* Remove banners
= Version 1.11.1 =
* Live chat for helping setup.
* Couple of bug fixes
* Another mobile app template
= Version 1.12 =
* Amazing new mobile themes
* Android push notes installed
* iOS push notes installed
* mobile app updated
= Version 1.13 =
* Quick bug fixes
= Version 1.14.1 =
* Quick bug fixes
= Version 1.15.1 =
* New Woocommerce theme
= Version 1.15.2 =
* Quick bug fixes
= Version 1.15.3 =
* Quick bug fixes
* Woocommerce increase functions
* Push notes update
= Version 1.15.4 =
* Increased the margin on header
* Push simulator
= Version 1.15.5 =
* Adding a deactivation module for plugins that don’t work on mobile
* Mobile push notification fix
= Version 1.15.6 =
* Fix conflict with Revolution Slider
* Fix cordova alert on mobile site.
= Version 1.15.7 =
* Fix conflict small conflict
= Version 1.15.8 =
* Image upload conflict fix
* Json warning fixed
* Cron added for push notifications
* Full demo thanks appetize.io
* Changes in pricing
= Version 1.15.9 =
* Image upload conflict fix
* Use any theme theme redirect
* Create your own theme
* Mobile header & footer on any page
* New instant demo
* Debug with deactivate plugins on mobile
* Buddypress more integration
= Version 1.15.10 =
* Fixes of a few bug
* Creation of new demo process
* Android Free for all
= Version 1.15.12 =
* Fixes of a few bug with the simulator
= Version 1.15.14 =
* Fix the bottom bar
* Fix the QRcode
= Version 1.15.15 =
* 20 new themes
* iBeacons compatible mobile app
= Version 1.15.17 =
* Bug fixes
* Removal of null themes.
= Version 1.15.18 =
* Bug fixes
* Adding WooCommerce compatibility to all the themes
= Version 1.15.19 =
* Bug fixes for redirect errors
* Themes added
* Preparing for WordPress update
= Version 1.15.23 =
* Bug fixes
* Versions
* New Themes
* New Helpdesk
* Splash screen fixed
* Decrease in size of plugin
= Version 1.16.1 =
* Bug fixes
* New Themes
= Version 1.16.3 =
* Mobile site fix
* More languages added
= Version 1.16.6 =
* Better mobile app themes being added.
= Version 1.16.6 =
* more mobile app themes being added.
* WP Head remove for mobile app with an option to reactivate.
* Better CSS
= Version 1.16.10 =
* New features for Mobile apps.
* bug fix
= Version 1.16.14 =
* Just added admob advertising. Monetize your apps now thanks to banner ads.
* Quicker install, default values added to the activation hook.
* Small bug fixes.
* New push notification system added (official launch December 19, 2016)
= Version 1.16.15 =
* Rewrite of the Push Notification system.
* Scheduled push notifications
* Push notification sent on new posts
* Faster loading mobile apps
= Version 1.16.16 =
* Mobile stats for downloads
* Fixed the redirect problem – Some users have had problems with the opening page.
* Making the setup better.
* Better preview functions.
* Fixed a problem not allowing the to change the colors of font in the top & bottom bar.
* YouTube videos will now open in a seperate window. Google no longer allow us to embed directly video which caused problems. Now, the videos will open in a browser.
* Hiding the slideshow tab for themes that are not compatible.
= Version 1.16.16 =
* fix for support button
* fix save buttons
== Upgrade notice ==



== Arbitrary section 1 ==
* We are currently upgrading the plugin for better woocommerce & buddypress integration.
